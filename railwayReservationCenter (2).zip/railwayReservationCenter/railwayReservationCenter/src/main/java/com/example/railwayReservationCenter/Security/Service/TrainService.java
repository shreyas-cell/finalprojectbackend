
package com.example.railwayReservationCenter.Security.Service;

import com.example.railwayReservationCenter.Models.Train;

import java.util.List;

public interface TrainService {
    Train saveTrain(Train train);
    List<Train> getAllTrains();
    Train getTrainById(int id);
    Train updateTrain(Train train,int id);

    List<Train> getTrainBySrcDes(String source,String destination);
    void deleteTrain(int id);

}
