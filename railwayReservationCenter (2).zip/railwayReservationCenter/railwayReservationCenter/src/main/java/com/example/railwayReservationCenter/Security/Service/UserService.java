package com.example.railwayReservationCenter.Security.Service;

import com.example.railwayReservationCenter.Models.User;

public interface UserService {
    public User updateUser(User user, int id);
}
