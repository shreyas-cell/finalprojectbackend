package com.example.railwayReservationCenter.Repository;

import com.example.railwayReservationCenter.Models.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.ResponseEntity;

import java.util.Optional;


public interface UserRepository extends JpaRepository<User,Integer> {
        Optional<User> findByUsername(String username);

        Boolean existsByUsername(String username);

        Boolean existsByEmail(String email);

        String existsUserByEmail(String email);
        User findUserByEmailIgnoreCase(String email);

        User findUserById(Integer id);

}
