package com.example.railwayReservationCenter.Repository;

import com.example.railwayReservationCenter.Models.Train;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
public interface TrainRepo extends JpaRepository<Train,Integer> {
    //Optional<Train> findByTrainName(String trainName)
    List<Train> findTrainBySourceAndDestination(String source,String destination);

}
