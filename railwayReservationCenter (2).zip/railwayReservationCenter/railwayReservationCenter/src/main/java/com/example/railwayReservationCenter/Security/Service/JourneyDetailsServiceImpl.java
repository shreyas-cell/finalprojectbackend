package com.example.railwayReservationCenter.Security.Service;

import com.example.railwayReservationCenter.Models.JourneyDetails;
import com.example.railwayReservationCenter.Repository.JourneyDetailsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class JourneyDetailsServiceImpl implements JourneyDetailsService{
    @Autowired
    JourneyDetailsRepo journeyDetailsRepo;
    public JourneyDetailsServiceImpl(JourneyDetailsRepo journeyDetailsRepo){
        this.journeyDetailsRepo=journeyDetailsRepo;
    }

    @Override
    public List<JourneyDetails> getByUser(int id) {

        return journeyDetailsRepo.findByUserId(id);
    }

    @Override
    public JourneyDetails saveJourney(JourneyDetails journeyDetails) {
        return  journeyDetailsRepo.save(journeyDetails);
    }

    @Override
    public void deleteJourney(int id) {
    journeyDetailsRepo.findById(id).orElseThrow();
    journeyDetailsRepo.deleteById(id);
    }

    @Override
    public List<JourneyDetails> getAllJourneys() {
        System.out.println("get all journey");
        return journeyDetailsRepo.findAll();
    }
}
