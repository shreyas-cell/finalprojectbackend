package com.example.railwayReservationCenter.Models;

public enum URole {
        ROLE_USER,
        ROLE_MODERATOR,
        ROLE_ADMIN
}
