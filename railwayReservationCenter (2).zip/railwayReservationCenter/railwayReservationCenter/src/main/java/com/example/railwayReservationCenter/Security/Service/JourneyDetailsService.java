package com.example.railwayReservationCenter.Security.Service;

import com.example.railwayReservationCenter.Models.JourneyDetails;

import java.util.List;
import java.util.Optional;


public interface JourneyDetailsService {
    List<JourneyDetails> getByUser(int id);
    JourneyDetails saveJourney(JourneyDetails journeyDetails);
    void deleteJourney(int id);
    List<JourneyDetails> getAllJourneys();

}
