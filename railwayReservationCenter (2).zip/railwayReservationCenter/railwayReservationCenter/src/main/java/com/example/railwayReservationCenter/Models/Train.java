package com.example.railwayReservationCenter.Models;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name="TrainDetails")
public class Train {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private Integer id;
    @Column(nullable = false)
    private String trainName;
    @Column(nullable = false)
    private Double departure;
    @Column(nullable = false)
    private Double arrival;
    @Column(nullable = false)
    private Double trainDuration;
    @Column(nullable = true)
    private Boolean ac1;
    @Column(nullable = true)
    private Boolean ac2;
    @Column(nullable = true)
    private Boolean ac3;
    @Column(nullable = true)
    private Boolean sl;
    @Column(nullable = false)
    private String source;
    @Column(nullable = false)
    private String destination;
    @Column(nullable = false)
    private Double ac1Fare;
    @Column(nullable = false)
    private Double ac2Fare;
    @Column(nullable = false)
    private Double ac3Fare;
    @Column(nullable = false)
    private Double slFare;
    @Column(nullable = false)
    private int ac1Available;
    @Column(nullable = false)
    private Integer ac2Available;
    @Column(nullable = false)
    private Integer ac3Available;
    @Column(nullable = false)
    private Integer slAvailable;



}
