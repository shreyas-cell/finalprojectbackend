package com.example.railwayReservationCenter.Payload.Request;

import javax.validation.constraints.NotBlank;

public class TrainRequest {
    @NotBlank
    private String source;

    @NotBlank
    private String destination;

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }


}
