package com.example.railwayReservationCenter.Security.Service;

import com.example.railwayReservationCenter.Models.Train;
import com.example.railwayReservationCenter.Repository.TrainRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class TrainServiceImpl implements TrainService{
    @Autowired
    private TrainRepo trainRepo;

    public TrainServiceImpl(TrainRepo trainRepo) {
        this.trainRepo = trainRepo;
    }
    @Override
    public Train saveTrain(Train train)
    {
        return trainRepo.save(train);
    }
    @Override
    public List<Train> getAllTrains()
    {
        return trainRepo.findAll();
    }
    @Override
    public Train getTrainById(int id)
    {
        return trainRepo.findById(id).orElseThrow();
    }

    @Override
    public List<Train> getTrainBySrcDes(String source,String destination ){
        return trainRepo.findTrainBySourceAndDestination(source,destination);
    }
    @Override
    public Train updateTrain(Train train,int id)
    {
        Train existingTrain=trainRepo.findById(id).orElseThrow();
        existingTrain.setTrainName(train.getTrainName());
        existingTrain.setDeparture(train.getDeparture());
        existingTrain.setArrival(train.getArrival());
        existingTrain.setTrainDuration(train.getTrainDuration());
        existingTrain.setAc1Fare(train.getAc1Fare());
        existingTrain.setAc2Fare(train.getAc2Fare());
        existingTrain.setAc3Fare(train.getAc3Fare());
        existingTrain.setSlFare(train.getSlFare());
        existingTrain.setAc1(train.getAc1());
        existingTrain.setAc2(train.getAc2());
        existingTrain.setAc3(train.getAc3());
        existingTrain.setSl(train.getSl());
        existingTrain.setSource(train.getSource());
        existingTrain.setDestination(train.getDestination());
        existingTrain.setAc1Available(train.getAc1Available());
        existingTrain.setAc2Available(train.getAc2Available());
        existingTrain.setAc3Available(train.getAc3Available());
        existingTrain.setSlAvailable(train.getSlAvailable());
        trainRepo.save(existingTrain);
        return existingTrain;
    }
    @Override
    public void deleteTrain(int id)
    {
        trainRepo.findById(id).orElseThrow();
        trainRepo.deleteById(id);
    }
}
