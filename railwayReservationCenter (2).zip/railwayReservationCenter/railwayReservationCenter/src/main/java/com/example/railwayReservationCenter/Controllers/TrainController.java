
package com.example.railwayReservationCenter.Controllers;



import com.example.railwayReservationCenter.Models.Train;
import com.example.railwayReservationCenter.Security.Service.TrainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/train")
public class TrainController {
    @Autowired
    private TrainService trainService;


    public TrainController(TrainService trainService) {
        this.trainService = trainService;
    }
    @PostMapping
    public ResponseEntity<Train> saveTrain(@RequestBody Train train)
    {
        return new ResponseEntity<Train>(trainService.saveTrain(train), HttpStatus.CREATED);
    }
    @GetMapping("/all")
    public List<Train> getAllTrains()
    {
        return trainService.getAllTrains();
    }
    @GetMapping("{id}")
    public ResponseEntity<Train> getTrainById(@PathVariable("id")int id)
    {
        return new ResponseEntity<Train>(trainService.getTrainById(id),HttpStatus.OK);
    }
    @GetMapping("{source}/{destination}")
    public List<Train> getTrainBySrcDes(@PathVariable("source" )String source,@PathVariable("destination")String destination)
    {
        System.out.println("inside get train by in controller");
        return trainService.getTrainBySrcDes(source,destination);
    }
    @PutMapping("{id}")
    public ResponseEntity<Train> updateTrain(@PathVariable("id")int id,@RequestBody Train train)
    {
        return new ResponseEntity<Train>(trainService.updateTrain(train,id), HttpStatus.OK);
    }
    @DeleteMapping("{id}")
    public ResponseEntity<String> deleteTrain(@PathVariable("id")int id)
    {
        trainService.deleteTrain(id);
        return new ResponseEntity<String>("Train deleted successfully",HttpStatus.OK);
    }
}
