package com.example.railwayReservationCenter.Controllers;



import com.example.railwayReservationCenter.Models.JourneyDetails;
import com.example.railwayReservationCenter.Models.User;
import com.example.railwayReservationCenter.Repository.UserRepository;
import com.example.railwayReservationCenter.Security.Service.JourneyDetailsService;
import com.example.railwayReservationCenter.Security.Service.UserDetailsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/test")
public class UserController {
    @Autowired
    UserRepository userRepository;
    @Autowired
    JourneyDetailsService journeyDetailsService;

    @Autowired
    UserDetailsServiceImpl userDetailsServiceImpl;

    @GetMapping("/all")
    public String allAccess() {
        return "Public Content.";
    }

    @GetMapping("/user")
    @PreAuthorize("hasRole('USER') or hasRole('MODERATOR') or hasRole('ADMIN')")
    public String userAccess() {
        return "User Content.";
    }

    @GetMapping("/mod")
    @PreAuthorize("hasRole('MODERATOR')")
    public String moderatorAccess() {
        return "Moderator Board.";
    }

    @GetMapping("/admin")
    @PreAuthorize("hasRole('ADMIN')")
    public String adminAccess() {
        return "Admin Board.";
    }

    @GetMapping("/showUsers")
    public List<User> getAllUsers(){
        return userRepository.findAll();
    }

    @PutMapping("{id}")
    public ResponseEntity<User> updateUser(@PathVariable("id")int id,@RequestBody User user){
        userRepository.findById(id).orElseThrow();
        System.out.println(user.getUsername());
        return new ResponseEntity<User>(userDetailsServiceImpl.updateUser(user,id), HttpStatus.OK);
    }
    @GetMapping("{id}")
    public User getUserById(@PathVariable ("id") int id){
    return userRepository.findUserById(id);
    }
    @DeleteMapping("{id}")
    public ResponseEntity<String> deleteUser(@PathVariable("id")int id)
    {
        String s=String.valueOf(id);
        userRepository.deleteById(Integer.parseInt(s));
        return new ResponseEntity<String>("User deleted successfully",HttpStatus.OK);
    }
    @GetMapping("/booking/{id}")
    public List<JourneyDetails> getByUser(@PathVariable("id") int id){
        System.out.println(id);
        return journeyDetailsService.getByUser(id);
    }
    @GetMapping("/booking")
    public List<JourneyDetails> getAllJourneys(){
       // System.out.println(journeyDetailsService.getAllJourneys());
        return journeyDetailsService.getAllJourneys();
    }
    @GetMapping("/getUsername/{email}")
    public User getUsername(@PathVariable("email") String email){
        return userRepository.findUserByEmailIgnoreCase(email);
    }
    @PostMapping
    public ResponseEntity<JourneyDetails> saveJourney(@RequestBody JourneyDetails journeyDetails){
        return new ResponseEntity<JourneyDetails>(journeyDetailsService.saveJourney(journeyDetails), HttpStatus.CREATED);
    }
    @DeleteMapping("/booking/{id}")
    public ResponseEntity<String> deleteJourney(@PathVariable("id") int id){
        String s=String.valueOf(id);
        journeyDetailsService.deleteJourney(Integer.parseInt(s));
        return new ResponseEntity<String>("Journey deleted successfully",HttpStatus.OK);
    }
}