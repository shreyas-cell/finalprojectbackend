package com.example.railwayReservationCenter.Models;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name="JourneyDetails")
public class JourneyDetails {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private Integer id;
    @Column(nullable = false)
    private String firstName;
    @Column(nullable = false)
    private  String lastName;
    @Column(nullable = false)
    private Integer age;
    @Column(nullable = false)
    private Date doj;
    @Column(nullable = false)
    private String journeyClass;
    @Column(nullable = false)
    private Integer userId;
    @Column(nullable = false)
    private Integer TrainId;
    @Column(nullable = false)
    private String trainName;
    @Column(nullable = false)
    private String source;
    @Column(nullable = false)
    private String destination;
    @Column(nullable = false)
    private Double departure;
    @Column(nullable = false)
    private Double arrival;
}
