package com.example.railwayReservationCenter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RailwayReservationCenterApplicationTests {

	@Test
	void contextLoads() {
	}

}
